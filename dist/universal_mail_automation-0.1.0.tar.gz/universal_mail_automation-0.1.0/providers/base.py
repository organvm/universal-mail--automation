"""
Abstract base class for email providers.

Defines the interface that all email provider implementations must follow,
enabling consistent behavior across Gmail, IMAP, Mail.app, and Outlook.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import List, Optional, Iterator, Dict, Any, Tuple, TYPE_CHECKING
from enum import Flag, auto

from core.models import EmailMessage, LabelAction, ProcessingResult
from core.rules import is_protected_sender

if TYPE_CHECKING:  # avoid any import-time coupling; AuditLog is duck-typed at runtime
    from core.audit import AuditLog


class ProviderCapabilities(Flag):
    """
    Flags indicating what features a provider supports.

    Used to adapt behavior for providers with different capabilities
    (e.g., Gmail has true labels, IMAP uses folders).
    """
    NONE = 0
    TRUE_LABELS = auto()          # Supports multiple labels per message (Gmail)
    FOLDERS = auto()              # Uses folders instead of labels (IMAP, Outlook)
    STAR = auto()                 # Can star/flag messages
    ARCHIVE = auto()              # Can archive (remove from inbox without deleting)
    BATCH_OPERATIONS = auto()     # Supports batch API calls
    SEARCH_QUERY = auto()         # Supports server-side search queries
    GMAIL_EXTENSIONS = auto()     # Supports Gmail IMAP extensions (X-GM-LABELS)
    CATEGORIES = auto()           # Supports color categories (Outlook)


@dataclass
class ListMessagesResult:
    """Result from listing messages, including pagination info."""
    messages: List[EmailMessage]
    next_page_token: Optional[str] = None
    total_estimate: Optional[int] = None


class EmailProvider(ABC):
    """
    Abstract base class for email provider implementations.

    Providers implement this interface to enable consistent email processing
    across different services. The class supports context manager protocol
    for clean connection management.

    Example:
        with GmailProvider() as provider:
            messages = provider.list_messages("has:nouserlabels", limit=100)
            for msg in messages.messages:
                label = categorize_message(...)
                provider.apply_label(msg.id, label)

    Attributes:
        name: Human-readable provider name
        capabilities: Flags indicating supported features
    """

    name: str = "abstract"
    capabilities: ProviderCapabilities = ProviderCapabilities.NONE

    # Whether this provider's apply_label() physically MOVES a message out of the
    # inbox (vs. adding an additive label that leaves it in place). True for
    # folder providers whose only "label" is the containing folder (Outlook,
    # Mail.app). False for Gmail (additive labels) AND for IMAP — even with
    # X-GM-LABELS, apply_label is +X-GM-LABELS / a COPY that leaves the original
    # in the inbox; IMAP's out-of-inbox departure happens via remove_label("INBOX")
    # or archive(), which are observed directly. Drives MOVED-vs-LABELED in the
    # audit receipt so the disposition reflects real semantics, not a capability
    # proxy. See core/audit.py.
    LABEL_IS_MOVE: bool = False

    def __enter__(self) -> "EmailProvider":
        """Context manager entry - establish connection."""
        self.connect()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        """Context manager exit - close connection."""
        self.disconnect()

    @abstractmethod
    def connect(self) -> None:
        """
        Establish connection to the email service.

        Called automatically when using context manager. May involve
        OAuth token refresh, IMAP login, etc.

        Raises:
            ConnectionError: If connection cannot be established
            AuthenticationError: If credentials are invalid
        """
        pass

    @abstractmethod
    def disconnect(self) -> None:
        """
        Close connection to the email service.

        Called automatically when exiting context manager. Should be
        idempotent (safe to call multiple times).
        """
        pass

    @abstractmethod
    def list_messages(
        self,
        query: str = "",
        limit: int = 100,
        page_token: Optional[str] = None,
    ) -> ListMessagesResult:
        """
        List messages matching the query.

        Args:
            query: Provider-specific query string (e.g., Gmail search syntax,
                   IMAP SEARCH criteria)
            limit: Maximum messages to return per page
            page_token: Token for fetching next page (from previous result)

        Returns:
            ListMessagesResult with messages and pagination info

        Note:
            Initial result may contain only message IDs. Call
            get_message_details() or batch_get_details() to fetch headers.
        """
        pass

    @abstractmethod
    def get_message_details(self, message_id: str) -> Optional[EmailMessage]:
        """
        Fetch full details for a single message.

        Args:
            message_id: Provider-specific message identifier

        Returns:
            EmailMessage with populated headers, or None if not found
        """
        pass

    def batch_get_details(
        self,
        message_ids: List[str],
    ) -> Dict[str, EmailMessage]:
        """
        Fetch details for multiple messages efficiently.

        Default implementation calls get_message_details() sequentially.
        Providers with batch APIs should override for better performance.

        Args:
            message_ids: List of message IDs to fetch

        Returns:
            Dict mapping message_id to EmailMessage (missing IDs omitted)
        """
        results = {}
        for msg_id in message_ids:
            msg = self.get_message_details(msg_id)
            if msg:
                results[msg_id] = msg
        return results

    @abstractmethod
    def apply_label(self, message_id: str, label: str) -> bool:
        """
        Add a label to a message.

        For folder-based providers, this may move the message to a folder.
        For label-based providers (Gmail), adds the label to the message.

        Args:
            message_id: Message to label
            label: Label/folder name to apply

        Returns:
            True if successful, False otherwise
        """
        pass

    @abstractmethod
    def remove_label(self, message_id: str, label: str) -> bool:
        """
        Remove a label from a message.

        Args:
            message_id: Message to modify
            label: Label/folder name to remove

        Returns:
            True if successful, False otherwise
        """
        pass

    def archive(self, message_id: str) -> bool:
        """
        Archive a message (remove from inbox without deleting).

        Default implementation removes "INBOX" label. Providers may override.

        Args:
            message_id: Message to archive

        Returns:
            True if successful, False otherwise
        """
        return self.remove_label(message_id, "INBOX")

    def star(self, message_id: str, due_date: Any = None) -> bool:
        """
        Star/flag a message for priority handling.

        Args:
            message_id: Message to star
            due_date: Optional due date for task integration (provider-specific)

        Returns:
            True if successful, False otherwise
        """
        if not (self.capabilities & ProviderCapabilities.STAR):
            return False
        return self.apply_label(message_id, "STARRED")

    def unstar(self, message_id: str) -> bool:
        """
        Remove star/flag from a message.

        Args:
            message_id: Message to unstar

        Returns:
            True if successful, False otherwise
        """
        if not (self.capabilities & ProviderCapabilities.STAR):
            return False
        return self.remove_label(message_id, "STARRED")

    def apply_category(
        self,
        message_id: str,
        category: str,
        color: str = "blue",
    ) -> bool:
        """
        Apply a color category to a message.

        Only supported by providers with CATEGORIES capability.
        Default implementation returns False.

        Args:
            message_id: Message to categorize
            category: Category name to apply
            color: Color for category (provider-specific)

        Returns:
            True if successful, False otherwise
        """
        if not (self.capabilities & ProviderCapabilities.CATEGORIES):
            return False
        return False  # Subclasses override

    @abstractmethod
    def ensure_label_exists(self, label: str) -> str:
        """
        Ensure a label/folder exists, creating if necessary.

        Args:
            label: Label/folder name (hierarchical with "/" separator)

        Returns:
            The provider-specific label ID or name

        Raises:
            PermissionError: If unable to create the label
        """
        pass

    def _drop_if_protected(self, action: LabelAction) -> bool:
        """Fail-closed never-archive gate, enforced at the provider CHOKEPOINT.

        The product's headline invariant — a protected sender is NEVER archived or
        moved out of inbox — lives HERE (and in the Gmail apply_actions override),
        because every provider funnels through apply_actions and the From is
        carried on LabelAction.sender. If the sender is protected, neutralize every
        out-of-inbox operation IN PLACE (archive=False; strip INBOX/\\Inbox from
        remove_labels) and return True so the caller can also suppress the
        label-as-MOVE for folder providers. A blank sender fails closed (protected).
        """
        if not is_protected_sender(action.sender):
            return False
        action.archive = False
        action.remove_labels = [
            lbl for lbl in action.remove_labels if lbl.upper() not in ("INBOX", "\\INBOX")
        ]
        return True

    def apply_actions(
        self,
        actions: List[LabelAction],
        audit: Optional["AuditLog"] = None,
    ) -> ProcessingResult:
        """
        Apply a batch of label actions.

        Default implementation processes actions sequentially. Providers
        with batch APIs should override for better performance.

        Args:
            actions: List of LabelAction objects to apply
            audit: Optional AuditLog. When supplied, each message's post-gate
                disposition (protected_held / archived / moved / labeled / kept)
                is recorded as an independent trust receipt — see core/audit.py.

        Returns:
            ProcessingResult with statistics and any errors
        """
        result = ProcessingResult()
        is_folder = bool(self.capabilities & ProviderCapabilities.FOLDERS)
        for action in actions:
            protected = self._drop_if_protected(action)
            # For providers where apply_label IS a move (Outlook/Mail.app), a
            # protected sender must not have labels applied either — that would
            # itself move the message out of the inbox.
            move_via_label = protected and self.LABEL_IS_MOVE
            # Observe what ACTUALLY happens, so the audit is a post-hoc witness of
            # real operations rather than a re-reading of the (gate-mutated) action.
            did_leave_inbox = False     # archive() or INBOX-removal actually ran
            did_label_move = False      # a move-on-label apply_label() actually ran
            applied_labels = []
            try:
                if not move_via_label:
                    for label in action.add_labels:
                        self.ensure_label_exists(label)
                        if self.apply_label(action.message_id, label):
                            result.add_label_stat(label)
                            applied_labels.append(label)
                            if self.LABEL_IS_MOVE:
                                did_label_move = True
                for label in action.remove_labels:
                    if self.remove_label(action.message_id, label) and \
                            label.upper() in ("INBOX", "\\INBOX"):
                        did_leave_inbox = True
                if action.archive:
                    if self.archive(action.message_id):
                        did_leave_inbox = True
                if action.star:
                    self.star(action.message_id, due_date=action.due_date)
                if action.category:
                    self.apply_category(
                        action.message_id,
                        action.category,
                        action.category_color or "blue",
                    )
                result.success_count += 1
            except Exception as e:
                result.error_count += 1
                result.errors.append(f"{action.message_id}: {e}")
            result.processed_count += 1

            if audit is not None:
                # Record AFTER execution, from the operations that actually ran.
                # Folder provider: leaving the inbox (by removal or move-on-label)
                # is a MOVE; label provider: INBOX-removal/archive is an ARCHIVE.
                # No `and not protected` fudge — if a regressed gate let a protected
                # message leave the inbox, archived/moved is TRUE here so the
                # receipt's invariant check fires instead of being silenced.
                if is_folder:
                    moved = did_leave_inbox or did_label_move
                    archived = False
                else:
                    archived = did_leave_inbox
                    moved = False
                audit.record(
                    message_id=action.message_id,
                    sender=action.sender,
                    protected=protected,
                    archived=archived,
                    moved=moved,
                    labels_added=applied_labels,
                )
        return result

    def get_label_cache(self) -> Dict[str, str]:
        """
        Get a mapping of label names to provider-specific IDs.

        Returns:
            Dict mapping label names to IDs (or names if no IDs)
        """
        return {}

    def health_check(self) -> Tuple[bool, str]:
        """
        Verify the provider connection is healthy.

        Returns:
            Tuple of (is_healthy, status_message)
        """
        try:
            self.list_messages(limit=1)
            return True, "OK"
        except Exception as e:
            return False, str(e)
